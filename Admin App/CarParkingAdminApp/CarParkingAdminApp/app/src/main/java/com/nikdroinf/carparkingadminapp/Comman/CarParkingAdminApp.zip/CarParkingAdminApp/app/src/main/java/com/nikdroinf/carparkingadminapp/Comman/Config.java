package com.nikdroinf.carparkingadminapp.Comman;

public class Config {

    private static String OnlineAddress = "http://192.168.43.87:80/car_parking/";
    public static String OnlineImageAddress = "http://192.168.43.87:80/smart_home_delivery/restaurantapp/upload/";

    public static String url_login = OnlineAddress+ "loginUser.php";


}
